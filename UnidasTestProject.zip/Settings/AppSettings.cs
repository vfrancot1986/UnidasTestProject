﻿namespace UnidasTestProject.Settings
{
    public static class AppSettings
    {
        public static string? UrlQA { get; set; }
        public static string? UrlDEV { get; set; }
        public static string? UrlHOM { get; set; }
        public static string? UserQA { get; set; }
        public static string? UserDEV { get; set; }
        public static string? UserHOM { get; set; }
        public static string? PasswordQA { get; set; }
        public static string? PasswordDEV { get; set; }
        public static string? PasswordHOM { get; set; }

    }
}
