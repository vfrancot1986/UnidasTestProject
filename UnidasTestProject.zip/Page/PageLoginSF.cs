﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using SeleniumExtras.WaitHelpers;

namespace UnidasTestProject.Page
{
    public class PageLoginSF
    {
        //Declaração de variáveis
        private IWebDriver _driver;
        private WebDriverWait _espera;

        //Mapeamento dos elementos
        [FindsBy(How = How.Id, Using = "username")]
        [CacheLookup]
        private IWebElement _txtNomeDoUsuario;

        [FindsBy(How = How.Id, Using = "password")]
        [CacheLookup]
        private IWebElement _txtSenha;

        [FindsBy(How = How.Id, Using = "Login")]
        [CacheLookup]
        private IWebElement _btnFacaLoginNoSandbox;

        [FindsBy(How = How.Id, Using = "logo")]
        [CacheLookup]
        private IWebElement _imgLogo;

        //Contrutor da classe
        public PageLoginSF(IWebDriver driver)
        {
            _driver = driver;
            _espera = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            PageFactory.InitElements(driver, this);
        }

        //Ações da página
        public void FazerLogin(string _usuario, string _senha)
        {
            _txtNomeDoUsuario.SendKeys(_usuario);
            _txtSenha.SendKeys(_senha);
            _btnFacaLoginNoSandbox.SendKeys(Keys.Enter);
        }
        public bool AguardaPagina()
        {
            _imgLogo = _espera.Until(ExpectedConditions.ElementExists(By.Id("logo")));
            return _imgLogo != null;
        }
    }
}